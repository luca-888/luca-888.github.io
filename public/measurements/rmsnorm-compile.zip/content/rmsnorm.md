# RMSNorm：计算原理与 GPU 算子优化

**RMSNorm 对每个 token 的 hidden 向量计算均方根，用它归一化输入，再按特征乘以可学习权重。**

输入记为 \(X[M,N]\)：\(M=\text{batch}\times\text{sequence}\) 是 token 数，\(N=\text{hidden size}\)。取一个 token 的输入向量 \(x=X[m,:]\)，\(x_i\) 表示第 \(i\) 个特征：

\[
y_i=\frac{x_i}{\operatorname{RMS}(x)}\cdot\gamma_i,
\qquad \text{where}\quad \operatorname{RMS}(x)=\sqrt{\epsilon+\frac{1}{N}\sum_{i=1}^{N}x_i^2}.
\]

- **RMS 沿 N 计算**：每个 token 得到一个标量；保留归约维度时，整批结果的形状为 \([M,1]\)。这里的 RMS 已包含 ε，用于防止除零。
- **γ 沿 M 共享**：形状为 \([N]\)，每个特征 \(i\) 有独立的 \(\gamma_i\)。同一列的所有 token 使用同一个权重。

忽略 ε 且输入非零时，\(x\) 除以自身 RMS 后，RMS 为 1；**乘 γ 后，输出 RMS 不必为 1。**

可以把一行的计算拆成：**平方 → 求均值 → 加 ε、求倒数平方根 → 缩放输入 → 乘 γ**。下面选取三行示例，观察每行的归一化系数和共享权重分别影响哪些输出。

::rmsnorm-demo::

LayerNorm 先减去均值，再按标准差缩放；RMSNorm 不减均值，直接按均方根缩放。两者都沿每个 token 的 hidden 维归约。

从计算结构看，forward 对每个 token 沿 N 归约，随后逐元素缩放；backward 还需要沿 M 累加共享权重 γ 的梯度。下面先用 PyTorch 表达 forward 和 backward，明确这两种归约与计算精度。

## 一、计算流程与 PyTorch 参考实现

代码中的 `x[M,N]` 表示整批输入，计算图展示其中一行；`gamma[N]` 在所有行之间共享。图与代码统一使用 `gamma` 表示 γ、`dgamma` 表示其梯度；本文输入与输出使用 BF16，中间计算使用 FP32。

### 1. 计算图与梯度流

`s` 为平方均值，`r = rsqrt(s + eps)`，`x_hat = x * r`；`g` 为输出 y 的上游梯度。Backward 从 g 沿箭头读取：**乘法传回上游梯度 × 另一输入；广播反向求和；两条路径的梯度相加。**

::rmsnorm-graph::

### 2. Forward 参考实现

返回 `y`，并保留 FP32 的 `r[M,1]` 供 Backward 复用。

```python
def rmsnorm_forward_reference(x, gamma, eps=1e-6):
    x_dtype = x.dtype
    x, gamma = x.float(), gamma.float()
    s = x.square().mean(dim=1, keepdim=True)
    r = torch.rsqrt(s + eps)
    x_hat = x * r
    y = x_hat * gamma
    return y.to(x_dtype), r
```

### 3. Backward 参考实现

`g[M,N]` 为上游梯度。复用 x、gamma 和 Forward 保存的 r，按图计算 dx_hat、dr，再合并两条路径得到 dx；dgamma 沿 M 累加。

```python
def rmsnorm_backward_reference(x, gamma, g, r):
    x_dtype, gamma_dtype = x.dtype, gamma.dtype
    x, gamma, g = x.float(), gamma.float(), g.float()
    N = x.shape[1]
    x_hat = x * r

    dx_hat = g * gamma
    dr = (dx_hat * x).sum(dim=1, keepdim=True)
    dx = r * dx_hat - x * r.pow(3) * dr / N
    dgamma = (g * x_hat).sum(dim=0)
    return dx.to(x_dtype), dgamma.to(gamma_dtype)
```

`dx_hat` 是传给 x_hat 的梯度；`dr` 沿 N 求和，`dgamma` 沿 M 求和。dx 由两条路径的贡献相加：固定 r 时的**直接路径贡献** `r * dx_hat`，以及 x 改变 r 带来的**经 r 路径贡献** `-x * r³ * dr / N`。

这些逐行归约和逐元素运算，在 eager 模式下会产生多少次 kernel launch 和中间张量读写？

## 二、PyTorch eager 性能基线与瓶颈分析

第一章给出了计算结果，接下来关注执行成本：**eager 会把这些张量运算逐个提交给 GPU，中间结果需要在 kernel 之间传递。** 先测量原样的 reference，再定位值得融合的部分。

### 1. 性能与显存基线

::rmsnorm-benchmark::

小输入的延迟受调用开销与运行波动影响；M 从 1024 增至 4096 时，延迟和显存占用都明显上升。优化需要同时减少中间张量的读写和占用。

### 2. 从表达式到 kernel

在 `M=1024, N=4096` 时，profiler 显示 BF16 的 Forward 启动 **9 个 kernel**，Backward 启动 **17 个**。

::rmsnorm-timeline::

下面按 kernel 执行顺序列出对应的 ATen 算子；类型转换统一列为 `aten::copy_`。

**Forward · 9 个 kernel**

```text
01  aten::copy_   x → FP32
02  aten::copy_   gamma → FP32
03  aten::pow     x.square()
04  aten::mean    沿 N 求均值 → s
05  aten::add     s + eps
06  aten::rsqrt   rsqrt(s + eps) → r
07  aten::mul     x * r → x_hat
08  aten::mul     x_hat * gamma → y
09  aten::copy_   y → BF16
```

**Backward · 17 个 kernel**

```text
01  aten::copy_   x → FP32
02  aten::copy_   gamma → FP32
03  aten::copy_   g → FP32
04  aten::mul     x * r → x_hat
05  aten::mul     g * gamma → dx_hat
06  aten::mul     dx_hat * x
07  aten::sum     沿 N 求和 → dr
08  aten::mul     r * dx_hat（直接路径贡献）
09  aten::pow     r.pow(3)
10  aten::mul     x * r³
11  aten::mul     上一步结果 * dr
12  aten::div     上一步结果 / N
13  aten::sub     第 08 步 − 第 12 步 → dx（两条路径贡献相加）
14  aten::mul     g * x_hat
15  aten::sum     沿 M 求和 → dgamma
16  aten::copy_   dx → BF16
17  aten::copy_   dgamma → BF16
```

**合并公式不会自动合并 kernel。** 代码中的一行 `dx = r * dx_hat - x * r.pow(3) * dr / N` 对应第 08–13 步，共 6 个 kernel；其中除 r³ 外，各步结果都是 `[M,N]`。

**FP32 中间张量增加读写与显存占用。** 在 `1024×4096` 下，输入 x 占 8 MiB，完整的 FP32 中间张量各占 16 MiB。仅写出、再读入 x_hat 就有 **32 MiB 的逻辑读写**，其中一部分可能命中缓存。多个中间张量同时存活，使 Forward、Backward 的峰值显存增量达到约 **56 MiB、128 MiB**；保存的 r 则只有 4 KiB。

**dgamma 需要跨行归约。** 第 07 步计算 dr，每行独立；第 15 步计算 dgamma，需要汇总所有 token 的贡献，因此还要单独组织跨行归约。

### 3. 必要读写量与带宽 SOL

**带宽 SOL（Speed of Light）估算的是：只搬运必要数据时，显存带宽允许的理想耗时。** 假设充分融合，每个大张量只读写一次，暂略较小的 gamma、r 和 dgamma：

| 阶段 | 必要读写 | BF16 数据量（字节） |
| :--- | :--- | ---: |
| Forward | 读取 x，写出 y | `2MN + 2MN = 4MN` |
| Backward | 读取 x、g，写出 dx | `2MN + 2MN + 2MN = 6MN` |

每个 BF16 元素占 2 字节。FP32 中间计算若保留在寄存器中，就不需要为这些中间结果增加显存读写。

RTX 4090 的理论显存带宽为 **1008 GB/s**，即每秒传输 `1008 × 10⁹` 字节。[NVIDIA 规格](https://images.nvidia.com/aem-dam/Solutions/Data-Center/l4/nvidia-ada-gpu-architecture-whitepaper-v2.1.pdf)

对 `M=4096, N=8192`，Forward 的必要数据量为 **128 MiB**，Backward 为 **192 MiB**。用数据量除以带宽：

\[
\begin{aligned}
T_{\text{forward}}^{\text{SOL}} &\approx \frac{128\times 2^{20}}{1008\times 10^9}\ \text{s} \approx 133.2\ \mu\text{s},\\
T_{\text{backward}}^{\text{SOL}} &\approx \frac{192\times 2^{20}}{1008\times 10^9}\ \text{s} \approx 199.7\ \mu\text{s}.
\end{aligned}
\]

同一 shape 下，Forward 的 eager 实测为 **1462.4 μs**，SOL 为 **133.2 μs**；Backward 实测为 **4007.8 μs**，SOL 为 **199.7 μs**。SOL 是数据经过显存时的理想参照，实际耗时还受计算、归约和缓存影响。

**SOL 用读写量估算，不能用峰值显存占用代替。**

### 4. 优化方向

trace 显示，当前实现把大量逐元素计算拆成独立 kernel。优化重点是**减少 launch 和中间张量读写，同时降低峰值显存**。

- **Forward**：融合平方、归约与缩放，让平方结果和 x_hat 留在 kernel 内。
- **dx**：融合 dr 的行内归约与后续梯度计算，避免写出 dx_hat 和两条路径上的完整 FP32 中间张量。
- **dgamma**：跨行汇总各 token 的贡献，兼顾归约效率与临时缓冲区大小。

下一章先用 `torch.compile` 观察自动融合能减少多少 kernel、耗时和显存占用，再确定 Triton 的优化重点。

## 三、torch.compile 编译优化与性能分析

`torch.compile` 能自动融合第一章的张量运算，减少 kernel launch 和中间张量读写。下面先看性能收益，再看生成的执行结构。

### 1. 编译参考实现

直接编译第一章的 Forward 和手写 Backward，保持 BF16 输入输出、FP32 中间计算与返回接口不变。

```python
forward_compiled = torch.compile(rmsnorm_forward_reference, fullgraph=True, dynamic=False)
backward_compiled = torch.compile(rmsnorm_backward_reference, fullgraph=True, dynamic=False)

y, r = forward_compiled(x, gamma)
dx, dgamma = backward_compiled(x, gamma, g, r)
```

默认后端 TorchInductor 在这里生成 Triton kernel。`fullgraph=True` 要求完整捕获函数，`dynamic=False` 针对具体 shape 编译；一张计算图仍可生成多个 kernel。[PyTorch 文档](https://docs.pytorch.org/docs/2.9/generated/torch.compile.html)

### 2. 性能与显存变化

::rmsnorm-compile-benchmark::

**大输入收益明显。** 以 `M=4096, N=8192` 为例，Forward 从 **1462.4 μs** 降至 **145.7 μs**，加速 **10.04×**；Backward 从 **4007.8 μs** 降至 **335.4 μs**，加速 **11.95×**。峰值显存分别从约 **448 MiB、896 MiB** 降至约 **64 MiB**，接近返回结果本身的大小。

**小输入仍受调用开销影响。** `128×4096` 与 `1024×4096` 的 Forward 即使只剩一个 kernel，整体耗时也略高于 eager。减少 kernel 数量能降低 GPU 执行成本，但不能保证每种 shape 都加速。五组输入的 y、r、dx、dgamma 均通过 reference 数值检查。

### 3. 编译器融合了什么

在 `4096×8192` 下，Forward 生成 **1 个 kernel**，Backward 生成 **2 个 kernel**：

::rmsnorm-compile-graph::

- **Forward**：平方、沿 N 归约和缩放融合，只写出 y 与保存的 r。
- **Backward**：一个 kernel 沿 M 归约得到 dgamma；另一个融合 dr 的行内归约和 dx 计算。

平方结果、x_hat、dx_hat 等完整的 FP32 中间张量不再写入显存，因而显存占用大幅下降。但 Forward 仍在归约后重新读取 x，Backward 的两个分支也分别读取 x、g，仍有数据复用空间。

::rmsnorm-compile-source::

第四章用手写 Triton 融合 dx 与 dgamma，让两个梯度分支共享输入读取，进一步减少访存。

## 四、Triton 梯度融合优化

在 `M=4096, N=8192` 下，手写 Triton 将 Backward 调用耗时从 **336.2 μs 降至 210.2 μs**，加速 **1.60×**。核心改动是**计算 dx 时同时累加 dgamma**，让两个分支复用已经读入的 x、g。Forward 继续使用第三章的 compile 实现。

### 1. 融合 dx 与 dgamma

compile 的两个 Backward kernel 分别计算 dx 和 dgamma，都需要读取 x、g。手写版将 4096 行分成 **128 组，每组 32 行**：第一个 kernel 逐行计算 dx，同时在 program 内累加这组的 dgamma；第二个 kernel 汇总各组的结果。

::rmsnorm-triton-graph::

**kernel 数仍是 2 个，但第二个 kernel 的输入变小了。** 它读取 `partial[128, 8192]`，无需再次遍历完整的 x、g。partial 使用 FP32，占 **4 MiB**。

### 2. 核心实现与读写量

第一个 kernel 每个 program 处理一组，使用 8 warps。以下节选核心逻辑，X、W、G、R 是输入指针，DX、P 分别指向 dx 和 partial：

```python
group = tl.program_id(0)
col = tl.arange(0, N)
gamma = tl.load(W + col).to(tl.float32)
dg = tl.full((N,), 0, tl.float32)
for offset in range(32):
    row = group * 32 + offset
    x = tl.load(X + row * N + col).to(tl.float32)
    g = tl.load(G + row * N + col).to(tl.float32)
    r = tl.load(R + row)
    dx_hat = g * gamma
    dr = tl.sum(dx_hat * x, 0)
    dx = r * dx_hat - x * (r * r * r) * dr / N
    tl.store(DX + row * N + col, dx)
    dg += g * (x * r)
tl.store(P + group * N + col, dg)
```

`dg` 是当前组的 dgamma 累加值。它与 dx 共用 x、g、r；gamma 也在组内复用。第二个 kernel 沿 partial 的 128 组求和，写出 BF16 dgamma。

只计算主要张量的逻辑读写量：

| 执行结构 | x、g 读取 | dx 写出 | partial 读写 | 合计（MiB） |
| :--- | ---: | ---: | ---: | ---: |
| 两个分支分别读取 | 256 | 64 | 0 | 320 |
| 融合两个分支 | 128 | 64 | 8 | 200 |

这里省略 gamma、r 和最终 dgamma 的小额读写，分开执行按每个分支各读一次 x、g 估算。**逻辑读写量减少约 37.5%**；它不是实测显存流量，缓存与 kernel 内的重复读取仍会影响实际访问。

### 3. 性能与显存代价

::rmsnorm-triton-benchmark::

**约 4 MiB 的额外空间，换来约 1.60× 的 Backward 加速。** GPU 执行与完整调用均明显缩短，说明收益也体现在 GPU 计算中。峰值显存从 **64.02 MiB 增至 68.02 MiB**，因为 partial 与 dx 输出同时存活。

本实现的 BF16 输入输出、FP32 中间计算与 reference 一致；随机输入、零输入及不同幅度输入均通过数值检查。这一结果对应 **`4096×8192`**，其他 shape 的表现仍需单独验证。

::rmsnorm-triton-artifacts::
